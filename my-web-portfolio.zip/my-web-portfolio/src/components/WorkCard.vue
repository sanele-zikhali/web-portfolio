<script setup>
import { RouterLink } from "vue-router";
const props = defineProps(["cardTitle", "cardImage", "workId", "workLink"]);
</script>
<template>
  <div class="work-card">
    <div class="work-card-img">
      <img :src="cardImage" :alt="cardTitle" />
    </div>
    <div class="work-card-details">
      <p class="work-title">{{ cardTitle }}</p>
    </div>
    <div class="work-card-action">
      <RouterLink :to="workLink" class="btn-custom primary"
        >See Project</RouterLink
      >
      <RouterLink :to="`/work-details/${workId}`" class="btn-custom"
        >Details</RouterLink
      >
    </div>
  </div>
</template>
