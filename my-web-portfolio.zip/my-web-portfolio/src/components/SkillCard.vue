<script setup>
const props = defineProps(["skillName", "skillSize"]);
</script>
<template>
  <!-- Skills Cards -->
  <div class="skill-card">
    <p class="skill-name">{{ skillName }}</p>
    <div class="skill-progress-wrapper">
      <div class="skill-progress" :style="{ width: skillSize }">
        <div class="skill-count">{{ skillSize }}</div>
      </div>
    </div>
  </div>
</template>
