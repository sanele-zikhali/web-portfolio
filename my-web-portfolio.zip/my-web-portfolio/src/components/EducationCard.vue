<script setup>
const props = defineProps([
  "yearFrom",
  "yearTo",
  "Title",
  "Academy",
  "EducationType",
  "Status",
  "Location",
]);
</script>
<template>
  <div class="education-card">
    <div class="year-completed">
      <p class="from">From - {{ yearFrom }}</p>
      <p class="to">To - {{ yearTo }}</p>
    </div>
    <div class="education-status">
      <div class="education-group">
        <div class="line">
          <div class="pointer-wrapper">
            <div class="pointer"></div>
          </div>
        </div>
        <div class="group">
          <p class="main-education-title">
            {{ Title }}
          </p>
          <p class="education-school">
            in <b>{{ Academy }}</b>
          </p>
          <p class="education-location">{{ Location }}</p>
          <p class="education-type">{{ EducationType }}</p>
          <p class="education-duration">
            From <b>{{ yearFrom }}</b> - <b>{{ yearTo }}</b>
          </p>
          <p class="learning-status">{{ Status }}</p>
        </div>
      </div>
    </div>
  </div>
</template>
