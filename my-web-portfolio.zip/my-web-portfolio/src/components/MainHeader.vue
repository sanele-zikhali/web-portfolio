<script setup>
import links from "../../data/navLinks.json";
import { ref } from "vue";

const isNavActive = ref(false);
function toggleMobileMenu() {
  isNavActive.value = !isNavActive.value;
}
</script>
<template>
  <header>
    <RouterLink to="/" class="logo">
      <h3>
        <font-awesome-icon icon="feather" />
        Port<span>Folio</span>
      </h3>
    </RouterLink>
    <div class="side-links">
      <div class="links">
        <RouterLink
          v-for="(link, index) in links"
          :key="index"
          class="navLink"
          :to="link.path"
          >{{ link.text }}</RouterLink
        >
      </div>
      <Transition name="change">
        <div
          v-if="!isNavActive"
          class="menu-toggler"
          @click="toggleMobileMenu()"
        >
          <div class="bar"></div>
          <div class="bar"></div>
          <div class="bar"></div>
        </div>
        <div
          v-else
          class="menu-toggler"
          id="close-menu"
          @click="toggleMobileMenu()"
        >
          <div class="bar close-bar"></div>
          <div class="bar close-bar"></div>
          <div class="bar close-bar"></div>
        </div>
      </Transition>
    </div>
    <Transition name="fade">
      <div class="mobile-menu" v-if="isNavActive">
        <div class="menu">
          <div class="mobile-menu-links">
            <RouterLink
              v-for="(link, index) in links"
              class="navLink"
              :to="link.path"
              @click="toggleMobileMenu()"
              >{{ link.text }}</RouterLink
            >
          </div>
        </div>
      </div>
    </Transition>
  </header>
</template>

<style scoped>
.change-enter-from,
.change-leave-to {
  opacity: 0;
  transform: translateX(100%) rotate(60deg);
}
.change-enter-to,
.change-leave-from {
  opacity: 1;
  transform: translateX(0%) rotate(0);
}
.change-enter-active {
  transition: 0.3s all;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  top: 50%;
}
.fade-enter-to,
.fade-leave-from {
  opacity: 1;
  top: 60%;
}
.fade-enter-active,
.fade-leave-active {
  transition: 0.3s ease-in;
}
.side-links {
  .links a.router-link-exact-active {
    color: #535496 !important;
  }
}
.mobile-menu-links a.router-link-exact-active {
  background: #535496 !important;
}
</style>
