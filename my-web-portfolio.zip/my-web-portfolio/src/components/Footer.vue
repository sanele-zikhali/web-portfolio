<script setup>
const currentYear = new Date().getFullYear();
</script>
<template>
  <footer>
    <p>All Right Reserved &copy; {{ currentYear }}</p>
    <p>Developed By <span>Sanele Gcina Zikhali</span></p>
  </footer>
</template>
