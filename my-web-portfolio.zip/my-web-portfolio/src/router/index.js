import { createRouter, createWebHistory } from "vue-router";
import HomeView from "@/views/HomeView.vue";
import SkillsView from "@/views/SkillsView.vue";
import EducationView from "@/views/EducationView.vue";
import WorkView from "@/views/WorkView.vue";
import WorkDetailsView from "@/views/WorkDetailsView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: HomeView,
    },
    {
      path: "/my-skills",
      name: "skills",
      component: SkillsView,
    },
    {
      path: "/work",
      name: "work",
      component: WorkView,
    },
    {
      path: "/education",
      name: "education",
      component: EducationView,
    },
    {
      path: "/work-details/:id",
      name: "workDetails",
      component: WorkDetailsView,
    },
  ],
});

export default router;
