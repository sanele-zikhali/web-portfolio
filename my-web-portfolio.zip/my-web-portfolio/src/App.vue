<script setup>
import { RouterView } from "vue-router";
import MainHeader from "./components/MainHeader.vue";
import Footer from "./components/Footer.vue";
</script>

<template>
  <MainHeader />
  <div class="main-container">
    <router-view v-slot="{ Component }">
      <transition name="fade">
        <component :is="Component" />
      </transition>
    </router-view>
    <!-- Footer -->
    <Footer />
    <!-- Footer Ends -->
  </div>
</template>

<style scoped>
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateX(-100%);
}
.fade-enter-to,
.fade-enter-from {
  opacity: 1;
  transform: translateX(0%);
}

.fade-enter-active {
  transition: 0.6s ease;
}
</style>
