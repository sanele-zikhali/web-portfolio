<script setup>
import { useRoute, useRouter } from "vue-router";
import works from "../../data/works.json";
const router = useRoute();
const workId = parseInt(router.params.id);
const work = works.find((work) => work.id === workId);
</script>
<template>
  <p class="page-title">Work Details</p>

  <div class="work-details">
    <div class="work-details-grid">
      <div class="work-details-image-wrapper">
        <img :src="work.image" :alt="work.title" />
      </div>
      <div class="work-details-summary">
        <p class="work-title">{{ work.title }}</p>
        <p class="stack-details">Stack Details</p>
        <div class="details-list">
          <div v-for="stack in work.details.stack" class="detais-list-wrappper">
            <font-awesome-icon class="stack-icon" icon="check-circle" />
            <p class="stack">{{ stack }}</p>
          </div>
        </div>
        <p class="work-description">- {{ work.details.description }}</p>
      </div>
    </div>
  </div>
</template>
