<script setup>
import SkillCard from "@/components/SkillCard.vue";
import skills from "../../data/skills.json";

console.log(skills);
</script>
<template>
  <div class="skills">
    <p class="page-title">My <b>Skills</b></p>
    <!-- Soft Skills -->
    <p class="skills-label mt-3">Soft Skills</p>
    <div class="skills-wrapper">
      <SkillCard
        v-for="softSkill in skills[1].softSkills"
        :skillSize="softSkill.size"
        :skillName="softSkill.name"
        :key="softSkill.id"
      />
    </div>
    <div class="skills-divider"></div>
    <!-- Hard Skills -->
    <p class="skills-label">Hard Skills</p>
    <div class="skills-wrapper">
      <SkillCard
        v-for="softSkill in skills[0].hardSkills"
        :skillSize="softSkill.size"
        :skillName="softSkill.name"
        :key="softSkill.id"
      />
    </div>
  </div>
</template>
