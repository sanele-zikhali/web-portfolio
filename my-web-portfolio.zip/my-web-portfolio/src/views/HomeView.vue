<script setup></script>

<template>
  <div class="main-body-wrapper">
    <div class="development-cycle">
      <div class="cycle-wrapper">
        <div class="cycle-stack html">
          <i class="fab fa-html5"></i>
        </div>
        <div class="cycle-stack css">
          <i class="fab fa-css3"></i>
        </div>
        <div class="cycle-stack js">
          <i class="fab fa-js"></i>
        </div>
        <div class="cycle-stack vue">
          <i class="fab fa-vuejs"></i>
        </div>
      </div>
    </div>
  </div>
  <!-- Hero Section -->
  <div class="body-wrapper">
    <div class="main-grid">
      <div class="main-col">
        <h1 class="welcome-text">
          Hi There,
          <br class="break" />
          I'm <span>Sanele Zikhali</span>
        </h1>
        <p class="welcome-subtext"><b>Web Development</b> Expert.</p>
        <div>
          <p class="social-title text-white">
            Simply, Follow me on social media for more info.
          </p>
        </div>
        <div class="social-links">
          <RouterLink
            class="social-link"
            to="https://www.facebook.com/sanelegcinazikhali"
          >
            <div class="social-link-wrapper">
              <p class="social-link-title">Facebook</p>
              <i class="fab fa-facebook-f social-icon"></i>
            </div>
          </RouterLink>
          <RouterLink
            class="social-link"
            to="https://github.com/sanele-zikhali"
          >
            <div class="social-link-wrapper">
              <p class="social-link-title">Github</p>
              <i class="fab fa-github social-icon"></i>
            </div>
          </RouterLink>
          <RouterLink class="social-link" to="">
            <div class="social-link-wrapper">
              <p class="social-link-title">Linked In</p>
              <i class="fab fa-linkedin-in social-icon"></i>
            </div>
          </RouterLink>
          <RouterLink class="social-link" to="">
            <div class="social-link-wrapper">
              <p class="social-link-title">Twitter</p>
              <i class="fab fa-twitter social-icon"></i>
            </div>
          </RouterLink>
        </div>
      </div>
      <div class="main-col" id="second-col">
        <div class="image-wrapper">
          <img src="../assets/img/developer.jpg" alt="" />
        </div>
        <p class="profession">Web Developer</p>
      </div>
    </div>
  </div>
  <!-- Profession Summary -->
  <section class="summary">
    <p class="section-title tagline">Summary</p>
    <div class="summary-wrapper">
      <div class="summary-text">
        <div class="summary-grid">
          <div class="summary-image">
            <img src="../assets/img/dev-summary.jpg" alt="" />
          </div>
          <p class="summary-shown">
            <span>S</span>elf-motivated, adaptable, and reliable front end web
            developer with 3+ years’ experience driving website and mobile-first
            application development projects.
          </p>
        </div>

        <p>
          <span class="summary-hidden"
            >Self-motivated, adaptable, and reliable front end web developer
            with 3+ years’ experience driving website and mobile-first
            application development projects.</span
          >
          Detail-oriented and efficient Web App developer skilled in building
          custom themes and templates, integrating plugins to support digital
          marketing efforts, and completing user experience (UX) copywriting
          tasks. Supportive team player with strong app development skills.
        </p>
      </div>
    </div>

    <section class="contact-me">
      <p class="section-title tagline">Contact Me</p>

      <div class="contact-wrapper">
        <div class="icon"><i class="fas fa-at"></i></div>
        <p class="contact-text">sanelecarl56@gmail.com</p>
      </div>
      <div class="contact-wrapper">
        <div class="icon"><i class="fas fa-phone"></i></div>
        <p class="contact-text">(+27)76 9757 684</p>
      </div>
    </section>
  </section>
  <!--Contact-->
</template>
<style scoped lang="scss">
.social-links {
  margin-top: 10px;
  display: flex;
  .social-link {
    font-size: 16px;
    border: 1px solid #535496;
    background: #535496c2;
    color: #fff;
    transition: 0.4s all;

    &:hover {
      color: #202020;
    }

    .social-link-wrapper {
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;

      .tooltip {
        background: #202020;
        padding: 2px 6px;
        color: #fff;
        position: absolute;
        top: 110%;
        border: 1px solid #535496;
        font-size: 12px;
        left: 0;
      }
    }

    &:not(:first-child) {
      margin-left: 8px;
    }
  }
  .facebook {
    background: #1d38d1;
    color: #fff;
  }
  .github {
    color: #fff;
    background: #000000;
  }
  .linkedin {
    background: #1762c4;
    color: #fff;
  }
}
</style>
