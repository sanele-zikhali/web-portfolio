<script setup>
import WorkCard from "@/components/WorkCard.vue";
import worksObj from "../../data/works.json";
const works = worksObj;
</script>
<template>
  <p class="page-title">My Work</p>
  <div class="my-work">
    <WorkCard
      v-for="work in works"
      :key="work.id"
      :workId="work.id"
      :workLink="work.workLink"
      :cardImage="work.image"
      :cardTitle="work.title"
    />
  </div>
</template>
