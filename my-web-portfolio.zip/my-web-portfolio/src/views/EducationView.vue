<script setup>
import EducationCard from "@/components/EducationCard.vue";
</script>
<template>
  <!-- <div>
    <h1>Getting Started with Vue.js and Font Awesome</h1>
    <p>Have a phone call: <font-awesome-icon icon="user" /></p>
  </div> -->
  <div class="education">
    <p class="page-title">Education</p>

    <div class="education-wrapper">
      <p class="education-card-title">
        <font-awesome-icon icon="graduation-cap" />
        Advanced Education
      </p>
      <EducationCard
        Title="Diploma In ICT Application Development"
        yearFrom="February 2020"
        yearTo="November 2022"
        Academy="Durban University of Technology"
        Location="Durban, KwaZulu-Natal"
        EducationType="University Diploma"
        Status="Completed"
      />
      <EducationCard
        Title="National Senior Certificate"
        yearFrom="January 2014"
        yearTo="November 2018"
        Academy="Esiphondweni High School"
        Location="Mboza Area, KwaZulu-Natal"
        EducationType="High School Diploma"
        Status="Completed"
      />
      <div class="education-divider"></div>
      <p class="education-card-title">
        <font-awesome-icon icon="certificate" /> Courses / Certifications
      </p>
      <EducationCard
        Title="Cisco Packet Tracer"
        yearFrom="March 2020"
        yearTo="June 2020"
        Academy="Durban University of Technology"
        Location="Durban, KwaZulu-Natal"
        EducationType="Certificate"
        Status="Completed"
      />
      <EducationCard
        Title="NGD LINUX"
        yearFrom="July 2020"
        yearTo="November 2020"
        Academy="Durban University of Technology"
        Location="Durban, KwaZulu-Natal"
        EducationType="Certificate"
        Status="Completed"
      />
      <EducationCard
        Title="Introduction In App Development"
        yearFrom="March 2022"
        yearTo="May 2022"
        Academy="IT Vasirty"
        Location="Online"
        EducationType="Certificate"
        Status="Completed"
      />
      <EducationCard
        Title="Android Development with React Native"
        yearFrom="April 2022"
        yearTo="December 2022"
        Academy="MTN Business App Academy"
        Location="Online"
        EducationType="NQF Level 6"
        Status="Completed"
      />
    </div>
  </div>
</template>
